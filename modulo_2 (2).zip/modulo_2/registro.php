<?php
session_start();
require_once "includes/db.php";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $login = trim($_POST["login"]);
    $pwd = $_POST["pwd"];
    $nombres = trim($_POST["nombres"]);
    $rol = trim($_POST["rol"]);

    if (empty($login) || empty($pwd) || empty($nombres) || empty($rol)) {
        $error = "Todos los campos son obligatorios.";
    } else {
        // Verificar si el usuario ya existe
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE login = :login");
        $stmt->execute([':login' => $login]);
        if ($stmt->fetch()) {
            $error = "El usuario ya existe.";
        } else {
            // Encriptar la contraseña
            $pwdHash = password_hash($pwd, PASSWORD_DEFAULT);

            // Insertar usuario
            $stmt = $pdo->prepare("INSERT INTO usuarios (login, pwd, nombres, rol) VALUES (:login, :pwd, :nombres, :rol)");
            $stmt->execute([
                ':login' => $login,
                ':pwd' => $pwdHash,
                ':nombres' => $nombres,
                ':rol' => $rol
            ]);

            $success = "Usuario creado correctamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Registrar Usuario</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="container mt-5">
    <h2>Registrar Nuevo Usuario</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-group">
            <label>Usuario (login):</label>
            <input type="text" name="login" class="form-control" required />
        </div>
        <div class="form-group">
            <label>Contraseña:</label>
            <input type="password" name="pwd" class="form-control" required />
        </div>
        <div class="form-group">
            <label>Nombres:</label>
            <input type="text" name="nombres" class="form-control" required />
        </div>
        <div class="form-group">
            <label>Rol:</label>
            <input type="text" name="rol" class="form-control" required />
        </div>
        <button type="submit" class="btn btn-primary mt-3">Crear Usuario</button>
    </form>
</body>
</html>
