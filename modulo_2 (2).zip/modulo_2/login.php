<?php
session_start();
require_once "includes/db.php";

$error = "";
$formEnviado = false;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $formEnviado = true; 
    $login = $_POST["login"];
    $pwd = $_POST["pwd"];

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE login = :login");
    $stmt->bindParam(':login', $login);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user && password_verify($pwd, $user['pwd'])) {
        $_SESSION['usuario'] = [
            'id' => $user['id'],
            'nombre' => $user['nombres'],
            'rol' => $user['rol']
        ];
        header("Location: index.php");
        exit;
    } else {
        $error = "Login o contraseña incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head><head>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Bootstrap CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
</head>
<body class="container mt-5">
    <h2>Inicio de Sesión</h2>
   <?php if ($formEnviado && $error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
    <form id="loginForm" method="POST" action="">
        <div class="form-group">
            <label>Usuario:</label>
            <input type="text" name="login" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Contraseña:</label>
            <input type="password" name="pwd" class="form-control" required>
        </div>
        <button class="btn btn-primary mt-3">Ingresar</button>
    </form>

    <script src="js/jquery.min.js"></script>
    <script>
    $("#loginForm").on("submit", function() {
        let login = $("input[name='login']").val().trim();
        let pwd = $("input[name='pwd']").val().trim();
        if (login === "" || pwd === "") {
            alert("Todos los campos son obligatorios.");
            return false;
        }
        return true;
    });
    </script>
</body>
</html>
