<?php
// Parámetros de conexión (puedes ponerlos en variables o archivo separado)
$host = "localhost";
$dbname = "gestion_proyectos";
$user = "root";
$pass = "";

try {
    // Crear conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    // Configurar el modo de error para lanzar excepciones
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Aquí puedes devolver la conexión para usarla en otros archivos
    return $pdo;

} catch (PDOException $e) {
    // Si hay error de conexión, puedes mostrar mensaje o manejarlo
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>


