<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['usuario'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio - Plataforma de Proyectos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
        }
        .dashboard {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
        }
        .welcome {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="welcome">
            <h2 class="text-primary">¡Bienvenido, <?= htmlspecialchars($user['nombre']) ?>!</h2>
            <p class="lead">Rol: <strong><?= $user['rol'] ?></strong></p>
        </div>

        <div class="d-grid gap-3">

            <?php if ($user['rol'] == 'Administrador'): ?>
                <a href="proyectos/listar.php" class="btn btn-outline-primary btn-lg">Gestionar todos los proyectos</a>

            <?php elseif ($user['rol'] == 'Lider'): ?>
                <a href="proyectos/crear.php" class="btn btn-outline-success btn-lg">Crear nuevo proyecto</a>
                <a href="proyectos/listar.php" class="btn btn-outline-primary btn-lg">Ver mis proyectos</a>

            <?php elseif ($user['rol'] == 'Estudiante'): ?>
                <a href="proyectos/listar.php" class="btn btn-outline-info btn-lg">Ver proyectos asignados</a>
            <?php endif; ?>

            <a href="logout.php" class="btn btn-outline-danger btn-lg">Cerrar sesión</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
