<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../includes/auth.php";
require_once "../includes/db.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM proyectos WHERE id = ?");
$stmt->execute([$id]);
$proyecto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$proyecto) {
    echo "<div class='alert alert-danger text-center mt-4'>Proyecto no encontrado.</div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
    <meta charset="UTF-8">
    <title>Editar Proyecto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Bootstrap CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-sm">
            <div class="card-header bg-warning text-white">
                <h4>Editar Proyecto</h4>
            </div>
            <div class="card-body">
                <form id="formEditar" action="actualizar.php" method="POST">
                    <input type="hidden" name="id" value="<?= $proyecto['id'] ?>">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del proyecto</label>
                        <input type="text" class="form-control" name="nombre" value="<?= htmlspecialchars($proyecto['nombre']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" name="descripcion" rows="4" required><?= htmlspecialchars($proyecto['descripcion']) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
                </form>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function () {
        $('#formEditar').submit(function () {
            let nombre = $('input[name="nombre"]').val().trim();
            let descripcion = $('textarea[name="descripcion"]').val().trim();

            if (nombre === '' || descripcion === '') {
                alert('Todos los campos son obligatorios.');
                return false;
            }
            return true;
        });
    });
</script>
</body>
</html>
