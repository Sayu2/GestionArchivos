<?php
// guardar.php

session_start();
if (!isset($_SESSION['usuario']) 
    || ($_SESSION['usuario']['rol'] != 'Líder de Proyecto' 
        && $_SESSION['usuario']['rol'] != 'Administrador')) {
    header('Location: ../login.php');
    exit;
}

require_once '../includes/db.php';

// Validación del lado del servidor
if (
    empty($_POST['nombre']) ||
    empty($_POST['descripcion']) ||
    !isset($_POST['miembros']) ||
    !is_array($_POST['miembros'])
) {
    die("Error: Todos los campos son obligatorios.");
}

$nombre       = trim($_POST['nombre']);
$descripcion  = trim($_POST['descripcion']);
$miembros     = array_unique($_POST['miembros']); // Evita duplicados
$fecha_creacion = date('Y-m-d H:i:s');

// Determinar quién será el líder
if ($_SESSION['usuario']['rol'] === 'Administrador') {
    // El administrador debe haber seleccionado un líder
    if (empty($_POST['id_lider'])) {
        die("Error: Debes seleccionar un líder para el proyecto.");
    }
    $id_lider = intval($_POST['id_lider']);
} else {
    // Si es Líder de Proyecto, se asigna a sí mismo
    $id_lider = $_SESSION['usuario']['id'];
}

try {
    $pdo->beginTransaction();

    // Insertar en proyectos, usando el líder correcto
    $stmt = $pdo->prepare("
        INSERT INTO proyectos 
            (nombre, descripcion, fecha_creacion, id_lider)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$nombre, $descripcion, $fecha_creacion, $id_lider]);
    $id_proyecto = $pdo->lastInsertId();

    // Validar miembros: solo estudiantes
    $placeholders = implode(',', array_fill(0, count($miembros), '?'));
    $stmt_validar = $pdo->prepare("
        SELECT id 
        FROM usuarios 
        WHERE id IN ($placeholders) 
          AND rol = 'Estudiante'
    ");
    $stmt_validar->execute($miembros);
    $miembros_validos = $stmt_validar->fetchAll(PDO::FETCH_COLUMN);

    // Insertar miembros válidos
    $stmt_miembros = $pdo->prepare("
        INSERT INTO proyecto_usuarios 
            (id_proyecto, id_usuario) 
        VALUES (?, ?)
    ");
    foreach ($miembros_validos as $id_usuario) {
        $stmt_miembros->execute([$id_proyecto, $id_usuario]);
    }

    // Registrar también al líder como miembro (si no está ya)
    if (!in_array($id_lider, $miembros_validos)) {
        $stmt_miembros->execute([$id_proyecto, $id_lider]);
    }

    $pdo->commit();
    header('Location: listar.php');
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die("Error al guardar el proyecto: " . $e->getMessage());
}
?>
