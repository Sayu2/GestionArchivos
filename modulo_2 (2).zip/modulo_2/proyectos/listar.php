<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/db.php';

checkLogin();

$usuario_id = $_SESSION['usuario']['id'];
$rol = $_SESSION['usuario']['rol'];

// 1) Administrador ve todos
if ($rol === 'Administrador') {
    $stmt = $pdo->query("
        SELECT p.*, u.nombres AS lider_nombre
        FROM proyectos p
        JOIN usuarios u ON p.id_lider = u.id
    ");

// 2) “Líder de Proyecto” ve solo sus proyectos
} elseif ($rol === 'Líder de Proyecto') {
    $stmt = $pdo->prepare("
        SELECT p.*, u.nombres AS lider_nombre
        FROM proyectos p
        JOIN usuarios u ON p.id_lider = u.id
        WHERE p.id_lider = ?
    ");
    $stmt->execute([$usuario_id]);

// 3) Estudiantes (o resto) ven solo donde participan
} else {
    $stmt = $pdo->prepare("
        SELECT p.*, u.nombres AS lider_nombre
        FROM proyectos p
        JOIN usuarios u ON p.id_lider = u.id
        JOIN proyecto_usuarios pu ON pu.id_proyecto = p.id
        WHERE pu.id_usuario = ?
    ");
    $stmt->execute([$usuario_id]);
}

$proyectos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
    <meta charset="UTF-8">
    <title>Mis Proyectos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2>Proyectos</h2>

    <?php if ($rol == 'Lider' || $rol == 'Administrador'): ?>
        <a href="crear.php" class="btn btn-success mb-3">+ Nuevo Proyecto</a>
    <?php endif; ?>

    <table class="table table-bordered table-striped shadow-sm">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Fecha de creación</th>
                <th>Líder</th>
                <?php if ($rol == 'Lider' || $rol == 'Administrador'): ?>
                    <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (count($proyectos) === 0): ?>
                <tr><td colspan="5" class="text-center">No hay proyectos disponibles.</td></tr>
            <?php else: ?>
                <?php foreach ($proyectos as $proyecto): ?>
                    <tr>
                        <td><?= htmlspecialchars($proyecto['nombre']) ?></td>
                        <td><?= htmlspecialchars($proyecto['descripcion']) ?></td>
                        <td><?= $proyecto['fecha_creacion'] ?></td>
                        <td><?= htmlspecialchars($proyecto['lider_nombre']) ?></td>
                        <?php if ($rol == 'Lider' || $rol == 'Administrador'): ?>
                            <td>
                                <a href="editar.php?id=<?= $proyecto['id'] ?>" class="btn btn-sm btn-primary">Editar</a>
                                <a href="eliminar.php?id=<?= $proyecto['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro que deseas eliminar este proyecto?')">Eliminar</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
