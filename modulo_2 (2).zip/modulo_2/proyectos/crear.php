<?php
// crear.php

session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['usuario']['rol'] != 'Lider' && $_SESSION['usuario']['rol'] != 'Administrador')) {
    header('Location: ../login.php');
    exit;
}

require_once '../includes/db.php';

// Obtener lista de usuarios para seleccionar miembros del proyecto
$stmt = $pdo->query("SELECT id, CONCAT(nombres, ' ', apellidos) AS nombre_completo FROM usuarios WHERE rol = 'Estudiante'");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtenemos todos los usuarios con rol "Líder de Proyecto"
$stmtLideres = $pdo->prepare("SELECT id, nombres FROM usuarios WHERE rol = ?");
$stmtLideres->execute(['Líder de Proyecto']);
$lideres = $stmtLideres->fetchAll(PDO::FETCH_ASSOC);

?>



<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
    <!-- Bootstrap CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Crear Proyecto</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js/jquery.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <h2>Crear Nuevo Proyecto</h2>
    <form id="formProyecto" action="guardar.php" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre del Proyecto:</label>
            <input type="text" class="form-control" id="nombre" name="nombre" required>
        </div>
        
        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea class="form-control" id="descripcion" name="descripcion" required></textarea>
        </div>

        <div class="form-group">
            <label for="miembros">Seleccionar Miembros:</label>
            <select class="form-control" id="miembros" name="miembros[]" multiple required>
                <?php foreach ($usuarios as $u): ?>
                    <option value="<?= $u['id'] ?>"><?= $u['nombre_completo'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

         <div class="form-group">
    <label for="id_lider">Líder del Proyecto:</label>
    <select name="id_lider" id="id_lider" class="form-control" required>
        <option value="">-- Selecciona un líder --</option>
        <?php foreach ($lideres as $l): ?>
            <option value="<?= $l['id'] ?>">
                <?= htmlspecialchars($l['nombres']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

        <button type="submit" class="btn btn-primary">Crear Proyecto</button>
         <a href="index.php" class="btn btn-secondary">Regresar</a>
    </form>
</div>

<script>
    // Validación con jQuery
    $(document).ready(function () {
        $('#formProyecto').submit(function () {
            let nombre = $('#nombre').val().trim();
            let descripcion = $('#descripcion').val().trim();
            let miembros = $('#miembros').val();

            if (nombre === '' || descripcion === '' || miembros.length === 0) {
                alert("Todos los campos son obligatorios.");
                return false;
            }
        });
    });
</script>
</body>
</html>
