<?php
session_start();
require_once "../includes/auth.php";
require_once "../includes/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombre'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';

    if (!$id || !$nombre || !$descripcion) {
        die("Todos los campos son obligatorios.");
    }

    try {
        $stmt = $pdo->prepare("UPDATE proyectos SET nombre = :nombre, descripcion = :descripcion WHERE id = :id");
        $stmt->execute([
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'id' => $id
        ]);

        header("Location: listar.php?msg=actualizado");
        exit;
    } catch (PDOException $e) {
        die("Error al actualizar el proyecto: " . $e->getMessage());
    }
} else {
    header("Location: listar.php");
    exit;
}
