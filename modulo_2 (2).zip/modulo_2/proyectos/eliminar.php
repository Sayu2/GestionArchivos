<?php
session_start();
require_once '../includes/db.php';

// Validar sesión
if (!isset($_SESSION['usuario']) || ($_SESSION['usuario']['rol'] != 'Administrador' && $_SESSION['usuario']['rol'] != 'Lider')) {
    header('Location: ../login.php');
    exit;
}

// Validar que se proporcione un ID de proyecto
if (!isset($_GET['id'])) {
    die("ID de proyecto no proporcionado.");
}

$id = $_GET['id'];

try {
    // Primero elimina las relaciones con usuarios (si tienes tabla proyecto_usuarios)
    $stmt = $pdo->prepare("DELETE FROM proyecto_usuarios WHERE id_proyecto = ?");
    $stmt->execute([$id]);

    // Luego elimina el proyecto
    $stmt = $pdo->prepare("DELETE FROM proyectos WHERE id = ?");
    $stmt->execute([$id]);

    // Redirigir de vuelta a la lista
    header('Location: listar.php');
    exit;
} catch (Exception $e) {
    error_log("Error al eliminar el proyecto: " . $e->getMessage());
    echo "Error al eliminar el proyecto. Intenta de nuevo.";
}
?>

